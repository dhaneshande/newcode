#!/bin/bash

ansible-playbook site.yml
