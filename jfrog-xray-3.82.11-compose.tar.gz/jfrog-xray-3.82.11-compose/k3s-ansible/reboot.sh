#!/bin/bash

ansible-playbook reboot.yml
